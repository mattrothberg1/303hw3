#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "support.h"
#include "structs.h"
#include <malloc.h>

DirectoryDescriptor *root = NULL;
DirectoryDescriptor *directory_cl = NULL;//present location
FatNode *fat = NULL;
Garbage * garbage = NULL;
int *id = NULL;
FILE * f = NULL;
int fs;
void *map = NULL;
char* generateData(char *source, size_t size)
{
	char *retval = (char *)malloc((size >> 1) * sizeof(char));

	for(size_t i=0; i<(size-1); i+=2)
	{
		sscanf(&source[i], "%2hhx", &retval[i>>1]);
	}
	return retval;
}

int isFileExist(char* filename) {
	DirectoryDescriptor *dd;
	for (int i = 0; i < NB_BLOCK; i++) {
		if (id[i] == ISDIRECTORY) {
			dd = map + i*BLOCK_SIZE;
			for (int j = 0; j < dd->count; j++) {
                //printf("%s",dd->table[j].filename);
				if (!strcmp(dd->table[j].filename,filename)) {
					return dd->table[j].index;
				}
			}
		}
	}
	return 0;
}
int setIsDirectory(int index,int status) {
    id[index] = status;
    write_IsDirectory(index,id);
    //printf("%s","new directory\n");
    return 1;
}
int isFileExistD(char * filename, DirectoryDescriptor *dd) {
    while (fat[dd->index].next!=NO_NEXT) {
        for(int i = 0; i < dd->count; i++) {
            if(!strcmp(filename,dd->table[i].filename)) {
                return dd->table[i].index;
            }
        }
        dd = (DirectoryDescriptor*)(map + fat[dd->index].next*BLOCK_SIZE);
    }
    for(int i = 0; i < dd->count; i++) {
        if(!strcmp(filename,dd->table[i].filename)) {
            return dd->table[i].index;
        }
    }
    return 0;
}
int findFreeBlock(){
	int blockStart;
	for (blockStart = ROOT + 1; blockStart < NB_BLOCK; blockStart++) {
		if (fat[blockStart].free == FREE) {
			break;
		}
	}
	if (blockStart == NB_BLOCK) {
		return 0;
	}
	return blockStart;
}
int setFreeBlock(int index, int status) {
    fat[index].free = status;
    write_FatNode(index,fat);
    return 1;
}
int setFatNext(int index,int next) {
    fat[index].next = next;
    write_FatNode(index,fat);
    return 1;
}

int createDirectoryDiscriptor(DirectoryDescriptor * dd) {
	int blockStart = findFreeBlock();
	if (!blockStart) {
		return 0;
	}
	//set newDD
	DirectoryDescriptor newDD;
	memset(&newDD,0,sizeof(newDD));
	newDD.index = blockStart;
	newDD.count = 0;
	//write newDD to disk
	write_blocks(blockStart,1,(void*)&newDD,map);
	//modify fat[newDD.index]
	setFreeBlock(blockStart,BUSY);
	//modify isDirectory
	setIsDirectory(newDD.index,ISDIRECTORY);

	//modify fat[dd->index]
	//printf("%i",dd->index);
	setFatNext(dd->index,blockStart);

	return blockStart;
}
int createFile(char * filename) {//crate file in current directory

    if(isFileExistD(filename,directory_cl)) {
        perror("ERROR: file exist");
        return 0;
	};
	int blockStart = findFreeBlock();
	if(!blockStart){
        perror("ERROR: NO SPACE");
		return 0;
	}
	//printf("%i",blockStart);
	DirectoryDescriptor * tempD = directory_cl;

	while(tempD->count == 3) {
		int next = fat[tempD->index].next;
		if (next == NO_NEXT) {
            setFreeBlock(blockStart,BUSY);
            int directoryStart = createDirectoryDiscriptor(tempD);
			if(!directoryStart) {
				return 0;
			} else {
			    tempD = (DirectoryDescriptor*)(map + directoryStart * BLOCK_SIZE);
			    //printf("\n%s %i\n","i get tempd",directoryStart);
				break;
			}
			setFreeBlock(blockStart,FREE);
		}
		tempD = (DirectoryDescriptor*)(map + next*BLOCK_SIZE);
	}

	for(int i = 0; i < 3; i++) {
		if ((*(char*)&(tempD->table[i])) == 0) {
            //reset datablock
			void * buffer = malloc(BLOCK_SIZE);
			memset(buffer,0,BLOCK_SIZE);
			write_blocks(blockStart, 1, buffer, map);
			free(buffer);
			//set fat
			setFreeBlock(blockStart,BUSY);
			//set id
			setIsDirectory(blockStart,NOTDIRECTORY);

            //set directoryDiscriptor

			FileDescriptor fd;
			memset(&fd,0,sizeof(fd));
			strcpy(fd.filename,filename);
			fd.index = blockStart;
			fd.timestamp = time(NULL);
			fd.size = 1;

			tempD->table[i] = fd;
			tempD->count+=1;
			//write tempD to disk
			msync(map + (tempD->index) * BLOCK_SIZE, BLOCK_SIZE, MS_SYNC);

			//set id


			return blockStart;
		}
	}
	return 0;
}
int dump(FILE* fout,int pageNum) {
    char* buffer = (char*)(map + pageNum * BLOCK_SIZE);
    char * out = malloc(BLOCK_SIZE);
    memcpy(out,buffer,BLOCK_SIZE);
	/*TODO
	use fprintf to printout in hex format
	*/
	for (int i = 0; i < BLOCK_SIZE; i++) {
        fprintf(fout,"%02hhx ",out[i]);
	}
	//all done;
	free(out);
	return 1;
}
int dumpBinary(char* fileName, int pageNum) {
	if (pageNum >= NB_BLOCK) {
		perror("ERROR:out of disk");
		return 0;
	}
	int file = isFileExistD(fileName,directory_cl);
	if(!file) {
        file = createFile(fileName);
	}
	memcpy(map + file * BLOCK_SIZE, map + pageNum * BLOCK_SIZE, BLOCK_SIZE);
	msync(map + file * BLOCK_SIZE, BLOCK_SIZE, MS_SYNC);
	setFreeBlock(file,BUSY);
	return file;

	return 1;
}
int usage() {
    int fs = 0;
    for (int i = 0; i < BLOCK_SIZE; i++) {
        if (fat[i].free == BUSY) {
            fs+=1;
        }
    }
    int f = fs;
    for (int i = 0; i < BLOCK_SIZE; i++) {
        if(id[i] == ISDIRECTORY)
        f--;
    }
    f-=ROOT;
    int fsb = fs * 512;
    int fb = f * 512;
    printf("filesystem use %i pages, %i bytes\nfile use %i pages, %i bytes",fs,fsb,f,fb);
    return 1;
}

int makedir(char * dName) {
    if(isFileExistD(dName,directory_cl)) {
        perror("ERROR: Directory already exist");
        return 0;
    }
    int blockStart = findFreeBlock();
	if (!blockStart) {
		return 0;
	}
	time_t now = time(NULL);
	//set self and father

	//set self
    FileDescriptor fd1;
	memset(&fd1,0,sizeof(FileDescriptor));
	char* fname1 = ".";
	strcpy(fd1.filename, fname1);
	fd1.index = blockStart;
	fd1.timestamp = now;
	//set father
    FileDescriptor fd2;
	memset(&fd2,0,sizeof(FileDescriptor));
	char* fname2 = "..";
	strcpy(fd2.filename, fname2);
	fd2.index = directory_cl->index;
	fd2.timestamp = now;

	//set newDD
	DirectoryDescriptor newDD;
	memset(&newDD,0,sizeof(newDD));
	newDD.index = blockStart;
	newDD.count = 2;
	newDD.table[0] = fd1;
	newDD.table[1] = fd2;

	//write newDD to disk
	write_blocks(blockStart,1,(void*)&newDD,map);

	//modify isDirectory
	setIsDirectory(newDD.index,ISDIRECTORY);

	//put newDD to directory_cl
    DirectoryDescriptor * tempD = directory_cl;

	while(tempD->count == 3) {
		int next = fat[tempD->index].next;
		if (next == NO_NEXT) {
            setFreeBlock(blockStart,BUSY);
            int directoryStart = createDirectoryDiscriptor(tempD);
			if(!directoryStart) {
				return 0;
			} else {
			    tempD = (DirectoryDescriptor*)(map + directoryStart * BLOCK_SIZE);
			    //printf("\n%s %i\n","i get tempd",directoryStart);
				break;
			}
			setFreeBlock(blockStart,FREE);
		}
		tempD = (DirectoryDescriptor*)(map + next*BLOCK_SIZE);
	}
    for(int i = 0; i < 3; i++) {
        if (!(*(char*)&(tempD->table[i]))) {
                strcpy(tempD->table[i].filename,dName);
                tempD->table[i].index = blockStart;
                tempD->table[i].timestamp = now;
                tempD->count++;
                msync(map + (tempD->index) * BLOCK_SIZE, BLOCK_SIZE, MS_SYNC);
                break;
        }

    }
    //modify fat[newDD.index] (this should be do at last)
	setFreeBlock(blockStart,BUSY);

	return blockStart;
}
int getFilesD(DirectoryDescriptor* dd, int * files) {// return fileNum

    int j = 0;
    DirectoryDescriptor* tempD = dd;
    for(int i = 0; i < 3; i++) {
        if (*(char*)&(tempD->table[i])) {
            files[j++] = tempD->table[i].index;
        }
    }
   while(fat[tempD->index].next!=NO_NEXT) {
        tempD = (DirectoryDescriptor*)(map + fat[tempD->index].next * BLOCK_SIZE);
        for(int i = 0; i < 3; i++) {
            if (*(char*)&(tempD->table[i])) {
                files[j++] = tempD->table[i].index;
            }
        }
    }
    return j;
}
int getFileSize(int file) {
    int size = 0;
    /*if(id[file]==ISDIRECTORY) {
        return size;
    }*/
    if(fat[file].free == BUSY){
        size++;
    }
    int tempf = file;
    while(fat[tempf].next != NO_NEXT) {
        tempf = fat[tempf].next;
        if(fat[tempf].free == BUSY) {
            size++;
        }
    }
    return size;
}
void getFileSizeR(int *total,int file) {
    if(id[file] == NOTDIRECTORY) {
        (*total) += getFileSize(file);
        return;
    }
    if(id[file] == -1) {
        return;
    }
    DirectoryDescriptor * dd = (DirectoryDescriptor *)(map + file * BLOCK_SIZE);
    int *files = malloc(sizeof(int) * NB_BLOCK);
    memset(files,0,sizeof(int) * NB_BLOCK);
    for(int i = 2; i < getFilesD(dd,files); i++) {
        getFileSizeR(total,files[i]);
    }
    free(files);
    return;
}

int ls() {
    DirectoryDescriptor* dd = directory_cl;

    for(int i = 0; i < 3; i++) {
        if (*(char*)&(dd->table[i])) {
            char name[FILE_NAME] = "";
            strcpy(name,dd->table[i].filename);
            int size = 0;
            //printf("%i",id[dd->table[i].index]);
            if(dd->table[i].index == -1) {
                printf("d      unknown %s\n",name);
            }
            else {
                char isd;
                if(id[dd->table[i].index] == ISDIRECTORY){
                    getFileSizeR(&size,dd->table[i].index);
                    isd = 'd';
                //printf("yes");
                } else {
                    size = getFileSize(dd->table[i].index);
                    isd = 'f';
                //printf("no");
                }
            printf("%c %12i %s\n",isd,size*BLOCK_SIZE,name);
            }
        }
    }
    while(fat[dd->index].next!=NO_NEXT) {
        dd = (DirectoryDescriptor*)(map + fat[dd->index].next * BLOCK_SIZE);
        for(int i = 0; i < 3; i++) {
            if (*(char*)&(dd->table[i])) {
                char name[FILE_NAME] = "";
                strcpy(name,dd->table[i].filename);
                int size = 0;
            if(dd->table[i].index == -1) {
                printf("d      unknown %s\n",name);
            } else {
                char isd;
                if(id[dd->table[i].index] == ISDIRECTORY){
                    getFileSizeR(&size,dd->table[i].index);
                    isd = 'd';
                //printf("yes");
                } else {
                    size = getFileSize(dd->table[i].index);
                    isd = 'f';
                //printf("no");
                }
                printf("%c %12i %s\n",isd,size*BLOCK_SIZE,name);
                }
            }
        }
    }
    return 1;
}
int cd(char* file) {
    int index = isFileExistD(file,directory_cl);
    if(!index) {
        perror("ERROR:directory not exist");
        return 0;
    }
    if (id[index] == NOTDIRECTORY) {
        perror("ERROR:directory not exist");
        return 0;
    }
    directory_cl = (DirectoryDescriptor*)(map + index * BLOCK_SIZE);
    return index;

}
char *getFileName(DirectoryDescriptor*dd, int fileIndex) {
    while (fat[dd->index].next!=NO_NEXT) {
        for(int i = 0; i < dd->count; i++) {
            if(fileIndex == dd->table[i].index) {
                return dd->table[i].filename;
            }
        }
        dd = (DirectoryDescriptor*)(map + fat[dd->index].next*BLOCK_SIZE);
    }
    for(int i = 0; i < dd->count; i++) {
        if(fileIndex == dd->table[i].index) {
                return dd->table[i].filename;
        }
    }
    return "";
}
int pwd() {
    DirectoryDescriptor * tempD = directory_cl;
    char * path[PATH_DEPTH];
    int i = 0;
    while(tempD->table[0].index!=ROOT) {
        int index = tempD->table[0].index;
        tempD = (DirectoryDescriptor*)(map + tempD->table[1].index * BLOCK_SIZE);
        path[i] = malloc(FILE_NAME);
        memset(path[i],0,FILE_NAME);
        char *filename = getFileName(tempD,index);
        strcpy(path[i],filename);
        i++;
    }
    i--;
    printf("/home");
    for(;i>=0;i--) {
        printf("/%s",path[i]);
        free(path[i]);
    }
    return 1;

}
int cat(char* fileName) {
    int file = isFileExistD(fileName,directory_cl);

    if(!file) {
        perror("ERROR: file not exist");
        return 0;
    }
    if(id[file]==ISDIRECTORY) {
        perror("ERROR: it's a directory");
        return 0;
    }
    char * buffer = (char*)malloc(BLOCK_SIZE);
    memcpy(buffer,map + file * BLOCK_SIZE,BLOCK_SIZE);
    for(int i = 0; i < BLOCK_SIZE;i++) {
        printf("%c",buffer[i]);
    }

    while (fat[file].next!=NO_NEXT) {
        file = fat[file].next;
        memcpy(buffer,map + file*BLOCK_SIZE,BLOCK_SIZE);
        for(int i = 0; i < BLOCK_SIZE;i++) {
            printf("%c",buffer[i]);
        }
    }
    free(buffer);
    return file;
}
DirectoryDescriptor* getDD(int file, int * rank) {
    //printf("enter with file %i\n",file);

    DirectoryDescriptor * tempD = directory_cl;

    while(fat[tempD->index].next!=NO_NEXT) {
        for(int i = 0; i < 3; i++) {
            if (tempD->table[i].index == file) {
                *rank = i;
                //printf("DD is %i", tempD->table[i].index);
                return tempD;
            }
        }
        tempD = map + fat[tempD->index].next * BLOCK_SIZE;
    }

    for(int i = 0; i < 3; i++) {
        if (tempD->table[i].index == file) {
            //printf("DD is %i", tempD->table[i].index);

            (*rank) = i;
            return tempD;
        }
    }
    //may need to be change
    return tempD;
}
int writef(char *fileName, int amt, char *data) {
    int file = isFileExistD(fileName,directory_cl);
    if(file && id[file]==ISDIRECTORY) {
        perror("ERROR: it's a directory");
        return 0;
    }
    if(!file) {
        file = createFile(fileName);
    }
    //printf("i'm the first original block %i\n",file);
    int blockO = getFileSize(file);
    //printf("original file size %i\n",blockO);

    if(blockO * BLOCK_SIZE < amt) {
        int moreBlock = amt % BLOCK_SIZE == 0 ? (amt - blockO * BLOCK_SIZE)/BLOCK_SIZE : (amt - blockO * BLOCK_SIZE)/BLOCK_SIZE + 1;
        //printf("moreblock %i\n",moreBlock);
        int * block = malloc(moreBlock * sizeof(int));
        for(int i = 0; i < moreBlock; i++) {
            block[i] = findFreeBlock();
            setFreeBlock(block[i], BUSY);
        }
        for(int i = 0; i < moreBlock; i++) {
            setFreeBlock(block[i],FREE);
           // printf("assign block %i\n",block[i]);
        }
        void * buffer =  malloc(BLOCK_SIZE);
        int i = 0;
        for(; i < blockO; i++) {
            memcpy(buffer, data + i * BLOCK_SIZE, BLOCK_SIZE);
            write_blocks(file, 1, buffer, map);
            file = fat[file].next;
        }
        //printf("if %i == %i, pass\n",file, NO_NEXT);
        file = isFileExistD(fileName,directory_cl);
        for(int j = 0; j < blockO - 1; j++){
            file = fat[file].next;
        }
        //printf("i'm the last original block %i\n", file);
        //printf("if %i == %i, pass\n",i, blockO);
        for(; i < moreBlock + blockO - 1; i++) {
            memcpy(buffer,data + i * BLOCK_SIZE, BLOCK_SIZE);
            //printf("assigned block %i written\n",block[i - blockO]);
            write_blocks(block[i - blockO],1,buffer,map);
            //set fat
            setFatNext(file,block[i - blockO]);
            setFreeBlock(block[i - blockO],BUSY);
            file = block[i - blockO];
            setIsDirectory(file,NOTDIRECTORY);
        }
        //printf("if %i the second last assigned block, pass\n",file);
        memset(buffer,0,BLOCK_SIZE);
        //printf("remain %i to be written\n",amt - (i * BLOCK_SIZE));
        //printf("written to assigned last block %i\n",block[i - blockO]);
        memcpy(buffer, data + i * BLOCK_SIZE, amt - (i * BLOCK_SIZE));
        //printf("prepare write to disk\n");

        write_blocks(block[i - blockO],1,buffer,map);
        //printf("finish written blocks\n");

        //set fat

        setFatNext(file,block[i - blockO]);
        setFreeBlock(block[i - blockO],BUSY);

        //set dd
        setIsDirectory(block[i - blockO], NOTDIRECTORY);

        //set fd in dd
        file = isFileExistD(fileName,directory_cl);
        DirectoryDescriptor* dd = getDD(file, &i);
        //printf("in DirectoryDescriptor %i",dd);
        //printf("index %i",i);


        dd->table[i].size = moreBlock + blockO;
        dd->table[i].timestamp = time(NULL);
        msync(dd,BLOCK_SIZE,MS_SYNC);
        free(buffer);
        free(block);

    } else {
        void * buffer = malloc(BLOCK_SIZE);
        memset(buffer,0,BLOCK_SIZE);
        int blockN = (amt % BLOCK_SIZE == 0 ? amt / BLOCK_SIZE : amt / BLOCK_SIZE + 1);
        int i = 0;
        for(; i < blockN - 1; i++) {
            memcpy(buffer, data + i * BLOCK_SIZE, BLOCK_SIZE);
            write_blocks(file, 1, buffer, map);
            file = fat[file].next;

        }
        memset(buffer,0,BLOCK_SIZE);
        memcpy(buffer, data + i * BLOCK_SIZE, amt - (i * BLOCK_SIZE));
        write_blocks(file,1,buffer,map);

        //set fat
        for(i = 0; i < blockN - 1; i++) {
            file = fat[file].next;
        }
        while(fat[file].next!=NO_NEXT){
            setFatNext(file,NO_NEXT);
            file = fat[file].next;
        }
        //set dd
        int file = isFileExistD(fileName,directory_cl);
        DirectoryDescriptor* dd = getDD(file, &i);
        dd->table[i].size = blockN;
        dd->table[i].timestamp = time(NULL);
        msync(dd,BLOCK_SIZE,MS_SYNC);
        free(buffer);
    }
    return 1;
}

int append(char* fileName, int amt, char *data) {
    int file = isFileExistD(fileName,directory_cl);
    if (!file) {
        perror("ERROR: file not exist");
        return 0;
    }
    if(id[file] == ISDIRECTORY) {
        perror("ERROR: it's a directory");
        return 0;
    }
    //printf("file at block %i\n",file);
    while(fat[file].next!=NO_NEXT) {
        file = fat[file].next;
    }
    //printf("append start from %i\n",file);

    char * buffer = malloc(BLOCK_SIZE);
    memcpy(buffer,map + file * BLOCK_SIZE,BLOCK_SIZE);
    //printf("file content:\n%s\n",buffer);
    int sizeU = strlen(buffer);
    //printf("file already in use %i bytes\n",sizeU);

    if(amt <= BLOCK_SIZE - sizeU) {
        char* newStr = malloc(BLOCK_SIZE);
        memset(newStr,0,BLOCK_SIZE);
        newStr = strcat(buffer,data);
        //printf("newstr:\n%s\n",newStr);
        write_blocks(file,1,newStr,map);
        free(newStr);
        //free(buffer);
        return 1;
    }
    //printf("need more blocks\n");

    char* newStr = malloc(BLOCK_SIZE);
    char* str2 = malloc(BLOCK_SIZE - sizeU);
    memcpy(str2,data,BLOCK_SIZE - sizeU);
    newStr = strcat(buffer,str2);
    //printf("content of file's first block\n%s\n",newStr);

    write_blocks(file,1,newStr,map);
    free(newStr);
    free(str2);
    buffer = malloc(BLOCK_SIZE);
    data = data + (BLOCK_SIZE - sizeU);
    amt = amt - (BLOCK_SIZE - sizeU);

    int blockN = amt%BLOCK_SIZE == 0 ? amt/BLOCK_SIZE : amt/BLOCK_SIZE + 1;
    int * block = malloc(sizeof(int) * blockN);

    for(int i = 0; i < blockN; i++) {
        block[i] = findFreeBlock();
        setFreeBlock(block[i], BUSY);
    }
    for(int i = 0; i < blockN; i++) {
        setFreeBlock(block[i],FREE);
    }
    int i = 0;
    for(; i < blockN - 1; i++) {
        memcpy(buffer, data + i * BLOCK_SIZE,BLOCK_SIZE);
        write_blocks(block[i],1,buffer,map);
        setFreeBlock(block[i],BUSY);
        setFatNext(file,block[i]);
        file = block[i];
        setIsDirectory(block[i],NOTDIRECTORY);
    }
    memset(buffer,0,BLOCK_SIZE);
    memcpy(buffer,data + i * BLOCK_SIZE, amt - i * BLOCK_SIZE);
    write_blocks(block[i], 1, buffer, map);
    setFreeBlock(block[i], BUSY);
    setFatNext(file, block[i]);
    setIsDirectory(block[i],NOTDIRECTORY);



    //set dd
    file = isFileExistD(fileName,directory_cl);
    DirectoryDescriptor* dd = getDD(file, &i);

    dd->table[i].size += blockN;
    dd->table[i].timestamp = time(NULL);
    msync(dd,BLOCK_SIZE,MS_SYNC);
    free(buffer);
    free(block);
    return 1;
}
int removef(char * fileName,int start, int end) {
    int file = isFileExistD(fileName,directory_cl);
    if (!file) {
       perror("ERROR: file not exist");
       return 0;
    }
    if(id[file] == ISDIRECTORY) {
        perror("ERROR: it's a directory");
    }
    int blockO = getFileSize(file);
    char *buffer = malloc(blockO * BLOCK_SIZE);
    for(int i = 0; i < blockO; i++) {
        memcpy(buffer + i * BLOCK_SIZE,map + file * BLOCK_SIZE,BLOCK_SIZE);
        file = fat[file].next;
    }

    char *str1 = malloc(start);
    memcpy(str1,buffer,start);
    char* str2 = malloc(strlen(buffer) - end);
    memcpy(str2,buffer+end,strlen(buffer) - end);
    char* newstr = malloc(strlen(buffer) - (end-start));
    newstr = strcat(str1,str2);
    writef(fileName,strlen(newstr),newstr);
    //sleep(0.1);
    //free(buffer);
    //free(newstr);
    //free(str2);
    return 1;
}
int getpages(char * fileName){
    int file = isFileExistD(fileName,directory_cl);
    if(!file) {
        perror("ERROR: file not exist");
    }
    if(id[file] == ISDIRECTORY) {
        DirectoryDescriptor* dd = map + file * BLOCK_SIZE;
        for(int i = 0; i < 3; i++) {
            if (*(char*)&(dd->table[i])) {
                printf("%i,",dd->table[i].index);
            }
        }
        while(fat[dd->index].next!=NO_NEXT) {
            dd = (DirectoryDescriptor*)(map + fat[dd->index].next * BLOCK_SIZE);
            for(int i = 0; i < 3; i++) {
                if (*(char*)&(dd->table[i])) {
                    printf("%i,",dd->table[i].index);
                }
            }
        }
    }else {
        while(fat[file].next!=NO_NEXT) {
            printf("%i,",file);
            file = fat[file].next;
        }
        printf("%i",file);
    }
    return 1;
}
int getf(char* fileName, int start, int end) {
    int file = isFileExistD(fileName,directory_cl);
    if (!file) {
       perror("ERROR: file not exist");
       return 0;
    }
    int blockO = getFileSize(file);
    //printf("%i",blockO);
    char *buffer = malloc(blockO * BLOCK_SIZE);
    for(int i = 0; i < blockO; i++) {
        memcpy(buffer + i * BLOCK_SIZE,map + file * BLOCK_SIZE,BLOCK_SIZE);
        file = fat[file].next;
    }
    char* out = malloc(end - start);
    memcpy(out, buffer+start, end - start);
    for(int i = 0; i < end - start; i++) {
        printf("%c",out[i]);
    }
    free(buffer);
    free(out);
    return 1;
}
int rmdirc(char* fileName){
    int file = isFileExistD(fileName,directory_cl);
    if(!file) {
        perror("ERROR: file not exist");
        return 0;
    }
    if(id[file] == NOTDIRECTORY) {
        perror("ERROR: it's not directory");
        return 0;
    }
    DirectoryDescriptor* dd = map + file * BLOCK_SIZE;
    int* files = malloc(NB_BLOCK * sizeof(int));
    int fileNum = getFilesD(dd,files);
    if(fileNum > 2) {
        perror("ERROR: can't remove, not empty");
        return 0;
    }
    setFreeBlock(file,FREE);
    setIsDirectory(file,NOTDIRECTORY);
    int i = 0;
    dd = getDD(file,&i);
    //printf("%i",i);
    dd->count--;
    memset(&dd->table[i],0,sizeof(FileDescriptor));
    write_blocks(dd->index,1,dd,map);
    for(int i = 0; i < GARBAGE_SIZE;i++) {
        if(garbage[i].index == 0) {
            strcpy(garbage[i].filename,fileName);
            garbage[i].index = file;
            write_Garbage(i,garbage);
            break;
        }
    }
    return 1;
}
int rmfile(char* fileName) {
    int file = isFileExistD(fileName,directory_cl);
    if(!file) {
        perror("ERROR: file not exist");
        return 0;
    }
    if(id[file] == ISDIRECTORY) {
        perror("ERROR: it's a directory");
        return 0;
    }
    while(fat[file].next!=NO_NEXT){
        setFreeBlock(file,FREE);
    }
    setFreeBlock(file,FREE);
    int i = 0;
    DirectoryDescriptor *dd = getDD(file,&i);
    //printf("%i",i);
    memset(&dd->table[i],0,sizeof(FileDescriptor));
    dd->count--;
    write_blocks(dd->index,1,dd,map);
    for(int i = 0; i < GARBAGE_SIZE;i++) {
        if(garbage[i].index == 0) {
            strcpy(garbage[i].filename,fileName);
            garbage[i].index = file;
            write_Garbage(i,garbage);
            break;
        }
    }
    return 1;
}
int rmForce(char * fileName) {
    int file = isFileExistD(fileName,directory_cl);
    if (!file) {
        perror("ERROR: file not exist");
        return 0;
    }
    if (file == ROOT){
        perror("ERROR: can't rm root");
        return 0;
    }
    if(id[file] == NOTDIRECTORY) {
        rmfile(fileName);
        return 1;
    }
    if(id[file] == ISDIRECTORY){
        DirectoryDescriptor * dd = (DirectoryDescriptor *)(map + file * BLOCK_SIZE);
        int* files = malloc(NB_BLOCK * sizeof(int));
        int fileNum = getFilesD(dd,files);
        if(fileNum == 2) {
            rmdirc(fileName);
            return 1;
        }
        cd(fileName);
        for(int i = 2; i < fileNum; i++) {
            rmForce(getFileName(dd,files[i]));
        }
        cd("..");
        rmdirc(fileName);
        free(files);
        return 1;
    }
}
/*void getAccessFile(int file,int *blocks){
    if(id[file] == NOTDIRECTORY) {
        blocks[strlen((char*)blocks)/sizeof(int)] = file;
        return;
    }
    if(id[file] == ISDIRECTORY){
        DirectoryDescriptor * dd = (DirectoryDescriptor *)(map + file * BLOCK_SIZE);
        int* files = malloc(NB_BLOCK * sizeof(int));
        int fileNum = getFilesD(dd,files);
        char *filename = getFileName(dd, file);
        cd(fileName);
        for(int i = 2; i < fileNum; i++) {
            getAccessFile(files[i],blocks);
        }
        cd("..");
        blocks[strlen((char*)blocks)/sizeof(int)] = file;
        free(files);
        return;
    }
}/*
int scandisk() {
    //get all access file
    int * blocks = malloc(sizeof(int)*BLOCK_SIZE);
    memset(blocks, 0, sizeof(int)*BLOCK_SIZE)
    getAccessFile(ROOT,blocks);
    for(int i : blocks) {

    }
}*/
void main()
{
        /*f = fopen("fs","w+");
		init_disk(f);
		fclose(f);*/

		fs = open("fs",O_RDWR);
		int SIZE = BLOCK_SIZE * NB_BLOCK;
		map = mmap(NULL,SIZE,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_SHARED,fs,0);
		//init_fs(fat, root, id, garbage,map);
        id = (int*)(map);
        fat = (FatNode*)(map + FILE_ALLOCATION_TABLE_START * BLOCK_SIZE);
        root = (DirectoryDescriptor*)(map + ROOT * BLOCK_SIZE);
        garbage = (Garbage*)(map + GARBAGE_START * BLOCK_SIZE);
        if(!verify_fs(fat, root, id, map)) {
            perror("ERROR: file system broken");
            exit(1);
        }else {
            directory_cl = root;
        }

        //printf("%i",isFileExist("."));
        //printf("%i",findFreeBlock());
        //setFreeBlock(ROOT+1,BUSY);
        //setFreeBlock(ROOT+1,FREE);
        printf("%i", createFile("test"));
        //printf("%i", createFile("test1"));
        //printf("%i",isFileExist("test1"));
        //dump(stdout,ROOT);
        //printf("%i",dumpBinary("hello",192));
       // dump(stdout,202);
        //usage();
        //printf("%i", createFile("test2"));
        //pwd();
        //printf("%i",makedir("directory1"));

        //printf("%i",makedir("directory2"));
        //printf("%i",makedir("directory3"));
        /*int *files = malloc(sizeof(int) * NB_BLOCK);
        memset(files,0,sizeof(int) * NB_BLOCK);
        for(int i = 0; i < getFilesD(directory_cl, files) ; i++) {
                printf("\nfile %i",files[i]);
        }
        free(files);*/
        //printf("%i",getFileSize(ROOT+1));
        /*int total = 0;
        getFileSizeR(&total,ROOT);
        printf("%i",total);*/

        //ls();
        //printf("%i",cd("directory1"));
        //printf("%i", createFile("test11"));
        //printf("%i", createFile("test12"));
        //ls();
        /*cd("directory2");
        makedir("directory21");
        cd("directory21");
        createFile("test211");
        pwd();
        ls();
        cd("..");
        pwd();*/

        //ls();
        //cat("hello");
        /*char data[20];
        for(int i = 0; i < 20; i++) {
            data[i] = 'o';
        }
        writef("test",20,data);
        ls();
        cat("test");*/

        /*char data2[2014];
        for(int i = 0; i < 2014; i++) {
            data2[i] = 'm';
        }
        append("test",2014,data2);
        cat("test");*/
        //removef("test",0,1000);
        //getpages("test");
        //getf(".",0,512);
        //rmdirc("directory1");
        /*ls();
        rmfile("test");
        ls();*/
        /*printf("%i",makedir("directory1"));*/

        //printf("%i",makedir("directory2"));
        //rmForce("directory1");
        ls();



}
