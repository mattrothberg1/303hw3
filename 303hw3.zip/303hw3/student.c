#include "support.h"

/*
 * Please be sure to fill in this struct right away!
 */
struct student_t student =
{
	"Yaodong Sheng,Matthew Rothberg,Neal Amin", /* member names, comma separated, e.g., Michael Spear */
	"yas616@lehigh.edu,mdr218@lehigh.edu,nea318@lehigh.edu"  /* member emails, comma separated, e.g., mfs409@lehigh.edu */
};
