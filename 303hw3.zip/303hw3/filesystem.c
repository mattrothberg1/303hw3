#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "support.h"
#include "structs.h"
#include "filesystem.h"

DirectoryDescriptor *root = NULL;
DirectoryDescriptor *directory_cl = NULL;//present location
FatNode *fat = NULL;
int *id = NULL;
FILE * f = NULL;
int fs = NULL;

/*
 * generateData() - Converts source from hex digits to
 * binary data. Returns allocated pointer to data
 * of size amt/2.
 */

char* generateData(char *source, size_t size)
{
	char *retval = (char *)malloc((size >> 1) * sizeof(char));

	for(size_t i=0; i<(size-1); i+=2)
	{
		sscanf(&source[i], "%2hhx", &retval[i>>1]);
	}
	return retval;
}

int dump(FILE* fout,int pageNum) {
	char* out = (char*)(map + pageNum * BLOCK_SIZE);
	/*TODO
	use fprintf to printout in hex format
	*/

	//all done;
	return 1;
}

int isFileExist(char* filename) {
	DirectoryDesctiptor *dd;
	for (int i = 0; i < NB_BLOCK; i++) {
		if (id[i] == IS_DIRECTORY) {
			dd = map + i*BLOCKSIZE;
			for (int j = 0; j < 3; j++) {
				if ((*dd).table[j].filename == filename) {
					return dd.table[j].index;
				}
			}
		}
	}
	return 0;
}
int findFreeBlock(){
	int blockStart;
	for (blockStart = ROOT + 1; blockStart < NB_BLOCK; blockStart++) {
		if (fat[blockStart].free == FREE) {
			fat[blockStart].free == BUSY;
			msync(fat+blockStart,sizeof(FatNode),MS_SYNC);
			return blockStart;
		}
	}
	if (blockStart == NB_BLOCK) {
		return 0;
	}
}

int createDirectoryDiscriptor(DirectoryDescriptor * dd) {
	blockStart = findFreeBlock();
	if (!blockStart()) {
		return 0;
	}
	DirectoryDescriptor newDD = NULL;
	newDD.index = blockStart;
	write_blocks(blockStart,1,(void*)&newDD,map);
	(*dd).next = blockStart;
	write_blocks(dd,1,(void*)dd,map);
	dd = (DirectoryDescriptor*)(map + blockStart * BLOCK_SIZE);
	isDirectory[blockStart] = ISDIRECTORY;
}



int createFile(char * filename) {
	int blockStart = findFreeBlock();
	if(!blockStart){
		return 0;
	}
	DirectoryDescriptor * tempD = directory_cl;
	while((*tempD).count == 3) {
		int next = fat[tempD.index].next;
		if (next == NO_NEXT) {
			if(!createDirectoryDiscriptor(tempD)) {
				return 0;
			} else {
				break;
			}
		}
		tempD = (DirectoryDescriptor*)(map + next*BLOCK_SIZE);
	}
	for(int i = 0; i < 3; i++) {
		if ((*tempD).table[i] == NULL) {
			void * buffer = malloc(BLOCK_SIZE);
			(*buffer) = NULL;
			write_blocks(blockStart, 1, buffer, map);
			FileDescriptor fd = NULL;
			fd.filename = filename;
			fd.index = blockStart;
			fd.timeStamp = time(NULL);
			fd.size = BLOCK_SIZE;
			(*tempD).table[i] = fd;
			(*tempD).count++;
			msync(tempD,sizeof(DirectoryDiscriptor),MS_SYNC);
			return blockStart;
		}
	}
	return 0;
}
int dumpBinary(int file, int blockNum) {
	if (blockNum >= NB_BLOCK) {
		perror("ERROR:out of disk");
		return 0;
	}
	memcpy(map + file * BLOCK_SIZE, map + blockNum, BLOCK_SIZE);
	msync(map + file * BLOCK_SIZE, BLOCK_SIZE, MS_SYNC);
	return 1;
}
/*
 * filesystem() - loads in the filesystem and accepts commands
 */
void filesystem(char *file)
{


	/* pointer to the memory-mapped filesystem */
	void *map = NULL;


	/*
	 * open file, handle errors, create it if necessary.
	 * should end up with map referring to the filesystem.
	 */
	f = fopen("fs","r");//fs is a filesystem's name
	if(f==NULL) {
		fclose(f);
		//create file
		f = fopen("fs","w+");
		init_disk(f);
		fclose(f);
		fs = open("fs",O_RDWR);
		int SIZE = BLOCK_SIZE * NB_BLOCK;
		map = mmap(NULL,SIZE,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_SHARED,fs,0);
		init_fs(fat, root, id, map);
	}
        id = (int*)(map);
        fat = (FatNode*)(map + FILE_ALLOCATION_TABLE_START * BLOCK_SIZE);
        root = (DirectoryDescriptor*)(map + ROOT * BLOCK_SIZE);
	if(!verify_fs(fat, root, id, map)) {
		perror("ERROR: file system broken");
		exit(1);
	}else {
		directory_cl = root;
	}


	/* You will probably want other variables here for tracking purposes */


	/*
	 * Accept commands, calling accessory functions unless
	 * user enters "quit"
	 * Commands will be well-formatted.
	 */
	char *buffer = NULL;
	size_t size = 0;
	while(getline(&buffer, &size, stdin) != -1)
	{
		/* Basic checks and newline removal */
		size_t length = strlen(buffer);
		if(length == 0)
		{
			continue;
		}
		if(buffer[length-1] == '\n')
		{
			buffer[length-1] = '\0';
		}

		/* TODO: Complete this function */
		/* You do not have to use the functions as commented (and probably can not)
		 *	They are notes for you on what you ultimately need to do.
		 */

		if(!strcmp(buffer, "quit"))
		{
			break;
		}
		else if(!strncmp(buffer, "dump ", 5))
		{
			if(isdigit(buffer[5]))
			{
				dump(stdout, atoi(buffer + 5));
			}
			else
			{
				char *filename = buffer + 5;
				char *space = strstr(buffer+5, " ");
				*space = '\0';
				//open and validate filename

				//validate filename
				if (sizeof(filename) > 32) {
					perror("Error: invalid filename");
					continue;
				}
				int file = isFileExist(filename);
				if (!file) {
					file = createFile(filename);
				}
				if(!dumpBinary(file, atoi(space + 1))){
					perror("Error:dump fail");
				};
			}
		}
		else if(!strncmp(buffer, "usage", 5))
		{
			//usage();
		}
		else if(!strncmp(buffer, "pwd", 3))
		{
			//pwd();
		}
		else if(!strncmp(buffer, "cd ", 3))
		{
			//cd(buffer+3);
		}
		else if(!strncmp(buffer, "ls", 2))
		{
			//ls();
		}
		else if(!strncmp(buffer, "mkdir ", 6))
		{
			//mkdir(buffer+6);
		}
		else if(!strncmp(buffer, "cat ", 4))
		{
			//cat(buffer + 4);
		}
		else if(!strncmp(buffer, "write ", 6))
		{
			char *filename = buffer + 6;
			char *space = strstr(buffer+6, " ");
			*space = '\0';
			size_t amt = atoi(space + 1);
			space = strstr(space+1, " ");

			char *data = generateData(space+1, amt<<1);
			//write(filename, amt, data);
			free(data);
		}
		else if(!strncmp(buffer, "append ", 7))
		{
			char *filename = buffer + 7;
			char *space = strstr(buffer+7, " ");
			*space = '\0';
			size_t amt = atoi(space + 1);
			space = strstr(space+1, " ");

			char *data = generateData(space+1, amt<<1);
			//append(filename, amt, data);
			free(data);
		}
		else if(!strncmp(buffer, "remove ", 7))
		{
			//remove(file, start, end);
		}
		else if(!strncmp(buffer, "getpages ", 9))
		{
			//getpages(buffer + 9);
		}
		else if(!strncmp(buffer, "get ", 4))
		{
			char *filename = buffer + 4;
			char *space = strstr(buffer+4, " ");
			*space = '\0';
			size_t start = atoi(space + 1);
			space = strstr(space+1, " ");
			size_t end = atoi(space + 1);
			//get(filename, start, end);
		}
		else if(!strncmp(buffer, "rmdir ", 6))
		{
			//rmdir(buffer + 6);
		}
		else if(!strncmp(buffer, "rm -rf ", 7))
		{
			//rmForce(buffer + 7);
		}
		else if(!strncmp(buffer, "rm ", 3))
		{
			//rm(buffer + 3);
		}
		else if(!strncmp(buffer, "scandisk", 8))
		{
			//scandisk();
		}
		else if(!strncmp(buffer, "undelete ", 9))
		{
			//undelete(buffer + 9);
		}



		free(buffer);
		buffer = NULL;
	}
	free(buffer);
	buffer = NULL;

}

/*
 * help() - Print a help message.
 */
void help(char *progname)
{
	printf("Usage: %s [FILE]...\n", progname);
	printf("Loads FILE as a filesystem. Creates FILE if it does not exist\n");
	exit(0);
}

/*
 * main() - The main routine parses arguments and dispatches to the
 * task-specific code.
 */
int main(int argc, char **argv)
{
	/* for getopt */
	long opt;

	/* run a student name check */
	check_student(argv[0]);

	/* parse the command-line options. For this program, we only support */
	/* the parameterless 'h' option, for getting help on program usage. */
	while((opt = getopt(argc, argv, "h")) != -1)
	{
		switch(opt)
		{
		case 'h':
			help(argv[0]);
			break;
		}
	}

	if(argv[1] == NULL)
	{
		fprintf(stderr, "No filename provided, try -h for help.\n");
		return 1;
	}

	filesystem(argv[1]);
	return 0;
}
